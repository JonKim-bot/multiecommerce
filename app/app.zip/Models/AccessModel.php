<?php namespace App\Models;

use App\Core\BaseModel;

class AccessModel extends BaseModel
{

    function __construct(){

        parent::__construct();

    }

}