
        <!--================Header Menu Area =================-->
        
        <!--================Home Banner Area =================-->
        <section class="home_banner_area" id="home">
            <div class="banner_inner">
				<div class="container">
					<div class="row banner_content">
						
					</div>
				</div>
            </div>
        </section>
        <style>
            p{
                color:black;
            }
        </style>
        <!--================End Home Banner Area =================-->
        
        <!--================Feature Area =================-->
        
        <!--================End Feature Area =================-->
        
        <!--================Interior Area =================-->
        
        <!--================End Interior Area =================-->
        
        <!--================Interior Area =================-->
        <section class="interior_area interior_two">
        	<div class="container">
        		<div class="interior_inner row">
        			<div class="col-lg-12 offset-lg-1">
        				<div class="interior_text">
        					<h4>TERM AND CONDITIONS</h4>
                            <h3>PLEASE READ THE FOLLOWING TERMS AND CONDITIONS AND THE GENERAL TERMS AND CONDITIONS OF SALE CAREFULLY AS THEY APPLY TO YOUR USE OF THIS WEBSITE AND SALE OF PRODUCTS THROUGH THIS WEBSITE.</h3><br>
        					<p>These terms and conditions of use (the “Terms and Conditions”), are intended to set forth the basic terms and conditions between you and PieGen Software Enterprise (Company No. 202003080465) or its affiliated companies (“Webi”, the “Company”, “we”, “our”, or “us”). The Website “http://webieasy.com/” is wholly owned by PieGen Software Enterprise (Company No. 202003080465). All the operations and services available in this website are fully managed and operated by PieGen Software Enterprise (Company No. 202003080465). All the contents residing in this website such as text, graphics, logos, and images are the properties of PieGen Software Enterprise (Company No. 202003080465) and/or its
                                respective owner.</p><br>
                       
        					<p>By accessing “http://webieasy.com/” or any sub-component thereof (this “Website”), you agree to be bound by these Terms and Conditions. IF YOU DO NOT AGREE TO THESE TERMS OR OUR PRIVACY POLICY, PLEASE DO NOT PLACE AN ORDER FROM THE SITE OR USE THE SITE OR ANY OF THE SERVICES PROVIDED ON THE SITE.<br>You agree that the Company may make agreements with you by electronic means and that such agreements are legal, authentic and valid for the purposes of the law.</p>
                            <p>Material from this Website is protected by copyright and may not be copied, reproduced,
                                distributed, republished, uploaded, posted, or transmitted in any way without the prior written
                                consent of the copyright owner.<br><br>
                                Use of the Website is void where prohibited by applicable law and the right to access the Website is
                                revoked in such jurisdictions.<br><br>
                                All trademarks on this Website are property of the Company unless otherwise indicated. The
                                Company name, and its brand; “Webi” and all related terms, names, logos, product and service names, designs and slogans, materials on this Website including the text, information, graphics, pricing, content, products and services are trademarks and intellectual property of the Company or its affiliates. You must not use such marks without the prior written permission of the Company or its owners. All other names, logos, product and service names, designs and slogans on this Website are the trademarks of their respective owners.<br><br>
                                Material on this Website is provided for lawful purposes only and in a manner which does not violate the rights of, or restrict or inhibit the use of this Website by any third party. Such restriction or inhibition includes, without limitation, conduct which is unlawful, or which may harass or cause distress or inconvenience to any person, the transmission of obscene or offensive content or of defamatory, racially or ethnically objectionable material of any kind or disruption of normal flow of dialogue within this Website.</p>
                            <h4>I. THIRD-PARTY HYPERLINKS</h4>
        					<p>The appearance on the website of external hyperlinks to third-party sites, in any form or content, does not constitute endorsement by the Company or any of our subsidiaries and affiliates, of the opinions or views expressed by any such third-party websites and we do not take responsibility for the accuracy, currency, completeness, or quality of the content contained at such sites. Furthermore, we are not responsible for the quality or delivery of the products or services offered, provided, accessed, or advertised by any third party. As such, neither we nor our subsidiaries and affiliates will be responsible or liable to you in any way for any content, errors or omissions, or for the results obtained from the use of any information contained in those third-party sites.</p>
                            <h4>II. DISCLAIMER AND LIMITATION OF LIABILITY/INDEMNITY:</h4>
                            <P>YOUR USE OF THIS WEBSITE IS AT YOUR SOLE RISK. THIS WEBSITE AND ALL CONTENT ARE DISTRIBUTED AND TRANSMITTED ON AN “AS IS” AND “AS AVAILABLE” BASIS, WITHOUT WARRANTIES OF ANY KIND, EITHER EXPRESS OR IMPLIED, INCLUDING WITHOUT LIMITATION, WARRANTIES OF MERCHANTABILITY OR FITNESS FOR A PARTICULAR PURPOSE.</P>
        					<p>We are not liable for any damages, harm, or injury that relates to, arises out of, or results from the use of, or access to, or the inability to use, any of the material on this Website. We
                                are not responsible or liable for any infections or contamination of your system, or delays, inaccuracies, errors, or omissions arising out of your use of this Website or with respect to any content contained on this Website. The entire risk as to the quality, accuracy, adequacy, completeness, correctness, and validity of any content rests with you.<br><br>
                                You may not misuse this website by knowingly introducing viruses, Trojans, worms, logic bombs or other material which is malicious or technologically harmful. You will not attempt to have any unauthorized access to this website, to the server which hosts this site or to any other server, computer or data base related to our website. You undertake not to attack this website via a denial of service attack or a distributed denial of service attack.<br><br>
                                By breaching this provision you may commit a criminal offence under the applicable regulations. We will report any such breach to the relevant law enforcement authority and we will co-operate with the appropriate authority to disclose the identity of the hacker. Likewise, in the event of such a breach, your right to use this website will cease immediately</p>
                            <p>TO THE FULLEST EXTENT PERMISSIBLE PURSUANT TO APPLICABLE LAW, THE COMPANY, OUR AFFILIATES, AND EACH OF OUR RESPECTIVE OFFICERS, DIRECTORS, EMPLOYEES, AGENTS, LICENSORS, REPRESENTATIVES, AND THIRD-PARTY PROVIDERS TO THE WEBSITE WILL NOT BE LIABLE FOR DAMAGES OF ANY KIND INCLUDING, WITHOUT LIMITATION, COMPENSATORY, CONSEQUENTIAL, INCIDENTAL, INDIRECT, SPECIAL OR SIMILAR DAMAGES, THAT MAY RESULT FROM THE USE OF, OR THE INABILITY TO USE, THE MATERIALS CONTAINED ON THIS WEBSITE, WHETHER THE MATERIAL IS PROVIDED OR OTHERWISE SUPPLIED BY THE COMPANY OR ANY THIRD PARTY.<br><br>
                                IN NO CASE SHALL THE COMPANY, ITS DIRECTORS, OFFICERS, EMPLOYEES, AFFILIATES, AGENTS, CONTRACTORS, OR LICENSORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, PUNITIVE, SPECIAL, OR CONSEQUENTIAL DAMAGES ARISING FROM YOUR USE OR INABILITY TO USE THE WEBSITE OR FOR ANY OTHER CLAIM RELATED IN ANY WAY TO YOUR USE OF THE WEBSITE, INCLUDING, BUT NOT LIMITED TO, ANY ERRORS OR OMISSIONS IN ANY CONTENT, OR ANY LOSS OR DAMAGE OF ANY KIND INCURRED AS A<br><br>
                                RESULT OF THE USE OF ANY CONTENT (OR PRODUCT) POSTED, TRANSMITTED, OR OTHERWISE MADE AVAILABLE VIA THE WEBSITE, EVEN IF ADVISED OF THEIR POSSIBILITY. IN THE EVENT THE PREVAILING LAWS DO NOT ALLOW THE EXCLUSION OR THE LIMITATION OF LIABILITY FOR CONSEQUENTIAL OR INCIDENTAL DAMAGES, THE COMPANY’S LIABILITY SHALL BE LIMITED TO THE EXTENT PERMITTED BY LAWS OF MALAYSIA.<br><br>
                                The Company shall use reasonable efforts to protect materials or information submitted by you in connection with the website, but you agree that your submission of such information is at your sole risk, and the Company hereby disclaims any and all liability to you for any loss or liability relating to such information in any way. The Company does not represent or guarantee that the website will be free from loss, corruption, attack, viruses, interference, hacking, or other security intrusion, and the Company disclaims any liability relating thereto.</p>
                                
                            <h4>III. LIMITATION OF TIME TO FILE A CLAIM, ONLINE PURCHASE DISCLAIMERS</h4>
        					<p>Any cause of action or claim you may have arising out of or relating to these Terms and Conditions of use or the website must be commenced within forty five (45) days from the date of purchase, otherwise, such cause of action or claim is permanently barred.<br><br>
                                In no event shall Webi be liable for loss of profit or goodwill, loss of production or revenue or any type of special indirect or consequential loss whatsoever (including loss or damage suffered by you as a result of an action brought by a third party) even if such loss were reasonably foreseeable or Webi has been advised of the possibility of you incurring the same.<br><br>
                                For the avoidance of doubt, Webi time of performance under this Agreement is not of essence.<br><br>
                                For the avoidance of doubt, Webi maximum and cumulative total liability (including any liability for acts and omissions of its employees, agents and sub-contractors) in respect of any and all claims for defective performance, breach of contract, compensation, indemnity, tort, misrepresentation, negligence at law or equity and any other damages or losses which may arise in connection with its performance or non-performance under the Agreement, shall not exceed the amount stated in the purchase order. If a number of events give rise substantially
                                to the same loss they shall be regarded as giving rise to only one claim under these Terms and Conditions.<br><br>
                                By making an offer to purchase merchandise, you expressly authorize Webi or any third party vendors utilized by Webi in connection with the processing of on-line payments to perform credit checks and verify the information provided. You confirm that the credit card that is being used is yours or that you have been specifically authorized by the owner of the card to use it. All credit card and their holders are subject to validation checks and authorization by the card issuer. If the issuer of the credit card refuses to authorize payment, Webi will not be liable for any delay or non-delivery of the Products.<br><br>
                                Furthermore, you agree that Webi or any third party vendors utilized by Webi in connection with the processing of on-line payments may use any information provided by you in order to conduct appropriate anti-fraud checks. Any information that you provide may be disclosed to a credit reference or fraud prevention agency, which may keep a record of that information.<br><br>
                                Further, by using this Website, you hereby agree that the Company and/or its affiliates may collect, obtain, store and process your personal data that you provide in this form for the purpose of considering your feedback and/or for receiving updates, news, promotional and marketing mails or materials from the Company. You hereby give your consent to the Company to: (a) store and process your Personal Data; (b) disclose your Personal Data to the relevant governmental authorities or third parties where required by law or for legal purposes. In addition, your personal data may be transferred to any company within Webi of companies which may involve sending your data to a location outside Malaysia.<br><br>
                                For the purpose of updating or correcting such data, you may at any time apply to the Company to have access to your personal data which are stored by the Company. For the avoidance of doubt, Personal Data includes all data defined within the Personal Data Protection Act 2010 including all data you have disclosed to the Company in this Website. Please refer to our Privacy Policy for further information about how Webi uses your personal data.<br><br>
                                All transactions on the Website are processed using SSL (Secure Sockets Layer) and/or TLS (Transport Layer Security), secure online payment systems that encrypt the credit card details
                                in a secure environment. Webi takes reasonable care to keep details of your details, orders records and other information secure, but Webi cannot be held liable for any loss you may suffer if a third party procures unauthorized access to any data provided when accessing or ordering from the Website.<br><br>
                                For more details and information on our online purchase orders terms and conditions, policies, procedures, cancellations policies etc, please kindly refer to our FAQs.</p>
                            <h4>IV. RISK AND TITLE</h4>
                            <p>Providing full payment of all sums due in respect of the products, including delivery charges have been made for the products purchased, the products will be at your risk from the time of delivery of the products to you; regardless of whether you actually physically take delivery of the products or not.</p>
                            <h4>V. WAIVER AND INDEMNITY</h4>
                            <p>By using the Website, you agree to indemnify and hold the company, its directors, officers,
                                employees, affiliates, agents, contractors, and licensors harmless with respect to any claims arising out of your breach of this Agreement, your use of the website, or any action taken by the Company as part of its investigation of a suspected violation of this agreement or as a result of its finding or decision that a violation of this agreement has occurred. This means that you cannot sue or recover any damages from the Company, its directors, officers, employees, affiliates, agents, contractors, and licensors as a result of its decision to remove or refuse to process any information, to warn you, to suspend or terminate your access to the website, or to take any other action during the investigation of a suspected violation or as a result of the company’s conclusion that a violation of this agreement has occurred. This waiver and indemnity provision applies to all violations described in, resulting from, or contemplated by this Agreement.</p>
                            <h4>VI. MODIFICATIONS TO WEBSITE</h4>
                            <p>We reserve the right to withdraw any products from this Website at any time and/or to remove or edit any materials or content on this Website at any time, without reference to any party. We will not be liable to you or any other third party by reason of our withdrawing any product from this Website or our removing or editing any materials or content on this Website. We may also terminate, change, suspend or discontinue any aspect of the Website
                                including but not limited to, hours of availability of the Website, and we will not be liable to you or to any third party for doing so.</p>
                            <h4>VII. TERMINATION</h4>
                        
                            <p>If you fail, or the Company suspects that you have failed, to comply with any of the provisions of this Agreement, the Company, at its sole discretion, without notice to you may: (i) terminate this Agreement and/or your Account; and/or (ii) terminate the license to the Website; and/or (iii) preclude access to the Website (or any part thereof).</p>
                            <h3>TERMINATION ON INSOLVENCY</h3>
                            <p>In the event:<br>
                                You make any voluntary arrangement with its creditors or become subject to an administration order or (being an individual or firm) becomes bankrupt or (being a company) goes into liquidation (otherwise than for the purposes of amalgamation or reconstruction); or <br>
                                1. You cease – or threaten to cease – to carry on business; or<br>
                                2. If we reasonably apprehend that any of the events mentioned above is about to occur in relation to you.<br>
                                3. Then without prejudice to any other right or remedy available to us, we shall be entitled to cancel the Agreement or suspend any further delivery/performance under the Agreement without any liability to you.
                                No person who is not a party to this Agreement (including any employee, officer, agent,
                                representative or sub-contractor of either party) shall have any right under the Contracts (Right of Third Parties) Act to enforce any terms of this Agreement.</p>
                            <h4>VIII. TRANSFER OF RIGHTS AND OBLIGATIONS</h4>
                            <p>The Agreement between you and us is binding on you and us and on our respective successors and assigns.<br><br>
                                You may not transfer, assign, charge or otherwise dispose of this Agreement, or any of your rights or obligations arising under it, without our prior written consent. We may transfer, assign, charge, subcontract or otherwise dispose of this Agreement, or any of our rights or obligations arising under it, at any time during the term of the Agreement. For the avoidance of doubt, any such transfer, assignment, charge or other disposition will not affect your
                                statutory rights as a consumer or cancel, reduce or otherwise limit any warranty or guarantee which may have been provided by us to you, whether express or implied.</p>
                            <h4>IX. EVENTS OUTSIDE OUR CONTROL</h4>
                            <p>We will not be liable or responsible for any failure to perform, or delay in performance of any of our obligations under a Contract that is caused by events outside our reasonable control (“KT Event”). A KT Event shall include any act, event, non-happening, omission or accident
                                Beyond our reasonable control and shall include in particular (without limitation) the following:<br><br>
                                1. Strikes, lock-outs or other industrial action.<br>
                                2. Civil commotion, riot, invasion, terrorist attack or threat of terrorist attack, war (whether declared or not) or threat or preparation for war.<br>
                                3. Fire, explosion, storm, flood, earthquake, subsidence, epidemic or other natural disaster.<br>
                                4. Impossibility of the use of railways, shipping, aircraft, motor transport or other means of public or private transport.<br>
                                5. Impossibility of the use of public or private telecommunications networks.<br>
                                6. The acts, decrees, legislation, regulations or restrictions of any government.<br>
                                7. Any shipping, postal or other relevant transport strike, failure or accidents.<br>
                                8. Interruption of production or operation, difficulties in obtaining raw materials, labour, fuel, parts or machinery.<br>
                                9. Power failure or breakdown in machinery.<br><br>
                                Our performance or obligations under any Agreement are deemed to be suspended for the period that the KT Event continues, and we will have an extension of time for performance for the duration of that period. We will use our reasonable endeavours to bring the KT Event to a close or to find a solution by which our obligations under the Contract may be performed despite the KT Event.</p>
                            <h4>X. WAIVER</h4>
                            <p>If we fail, at any time during the term of the Agreement, to insist upon strict performance of any of your obligations under the Agreement or any of these terms, or if we fail to exercise any of the rights or remedies to which we are entitled under these terms, this shall not constitute a waiver of such rights or remedies and shall not relieve You from compliance with such obligations.<br><br>
                                A waiver by us of any default shall not constitute a waiver of any subsequent default arising from the Agreement or the terms.<br><br>
                                No waiver by us of any of these terms or of any rights or remedies arising from the Agreement shall be effective unless it is expressly stated to be a waiver and is communicated to you in email.</p>
                            <h4>XI. SEVERABILITY</h4>
                            <p>If any of these terms or any provisions of the Agreement are determined by any competent
                                authority to be invalid, unlawful or unenforceable to any extent, such term, condition or provision will to that extent be severed from the remaining terms, conditions and provisions which will continue to be valid to the fullest extent permitted by law.</p>
                            <h4>XII. ENTIRE AGREEMENT</h4>
                            <p>These terms and any document expressly referred to in them represent the entire agreement
                                between you and us in relation to the subject matter of any Agreement and supersede any prior agreement, understanding or arrangement between you and us, whether oral or in writing.<br><br>
                                Both you and us acknowledge that, in entering into this Agreement, neither you nor us has relied on any representation, undertaking or promise given by the other or be implied from anything said or written in negotiations between you and us prior to such Agreement except as expressly stated in these terms.<br><br>
                                Neither you nor us shall have any remedy in respect of any untrue statement made by the other, whether orally or in writing, prior to the date of any Contract (unless such untrue statement was made fraudulently) and the other party ́s only remedy shall be for breach of contract as provided in these Terms.</p>
                            <h4>XIII. APPLICABLE LAWS</h4>
                            <p>The laws of the MALAYSIA govern these terms of sale of this Website and Agreement, and you irrevocably consent to the jurisdiction of the courts of Malaysia for any action arising out of or relating to these terms and conditions of sale. The Website has been designed to comply with the laws of Malaysia. If the Website fails to comply with the applicable legislation in the country from which you access the Website, you must stop using the Website forthwith.
                               </p><h3>DISCLAIMER, ERRORS & INACCURACIES</h3>
                               <p> Webi is not responsible for any inaccuracies or errors, or for any loss or damage caused by or arising from any user’s reliance on information obtained from or through this Website.<br><br>
                                Our goal is to provide complete, accurate, and up-to-date information on our Website.
                                Unfortunately, it is not possible to ensure that any Website is completely free of human or
                                technological errors. This Website may contain typographical mistakes, inaccuracies, or omissions, some of which may relate to pricing and availability, and product information. We reserve the right to correct any errors, inaccuracies or omissions, including after an order has been submitted and to change or update information at any time without prior or subsequent notice.</p>
                            

                        </div>
        			</div>
        
        		</div>
        	
        	</div>
        </section>
       
        
 

    </body>
</html>