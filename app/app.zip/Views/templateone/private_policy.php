
        <!--================Header Menu Area =================-->

        <!--================Home Banner Area =================-->
        <section class="home_banner_area" id="home">
            <div class="banner_inner">
				<div class="container">
					<div class="row banner_content">
						
					</div>
				</div>
            </div>
        </section>
        <style>
            p{
                color:black;
            }
        </style>
        <!--================End Home Banner Area =================-->
        
        <!--================Feature Area =================-->
        
        <!--================End Feature Area =================-->
        
        <!--================Interior Area =================-->
        
        <!--================End Interior Area =================-->
        
        <!--================Interior Area =================-->
        <section class="interior_area interior_two">
        	<div class="container">
        		<div class="interior_inner row">
        			<div class="col-lg-12 offset-lg-1">
        				<div class="interior_text">
        					<h4>PRIVACY POLICY</h4>
        					<p>We take our customer’s privacy seriously and we will only collect, record, hold, store and use your personal information as outlined below.<br><br>
                                Data protection is a matter of trust and your privacy is important to us. We shall therefore only process your name and other information which relates to you in the manner set out in this Privacy Policy. We will only collect information where it is necessary for us to do so and we will only collect information if it is relevant to our dealings with you. We will only keep your information for as long as we are either required to by law or as is relevant for the purposes for which it was collected.<br><br>
                                You can visit our website, and browse without having to provide your personal details. During your visit to our website, you may remain anonymous and at no time would we be able to identify you unless you have registered an account with us on our website and have logged on with your user name and password.</p>
                            <h4>COLLECTION OF PERSONAL INFORMATION</h4>
        					<p>We do not sell, share or trade customer’s personal information collected online with third parties. Personal information collected online will only be disclosed within our corporate group and to third parties for the purposes for which it was collected, as authorized and consented by you. For example, the conduct of a sales transaction of a product of your choice on our website.</p>
                            <h4>USE OF INFORMATION</h4>
        					<p>We use the personal information we collect from you for the following purposes</p>
                        
        					<p>1. To register and manage your account, where you have registered an account with us;<br>
                                2. To provide you with a quick and simple checkout experience;<br>
                                3. To process your orders, contact you concerning the status of an order, answer any of your questions, or otherwise contact you when necessary;<br>
                                4. To contact you about upcoming sales, promotions, and product information;<br>
                                5. To invite you to participate in contests and other promotions;<br>
                                6. To help us learn more about our site visitors and customers and to improve their shopping experience and our business;<br>
                                7. To personalize web content and advertising based on your characteristics or preferences<br>
                                8. To address problems with the Web Site, our business or our products and services and to protect the security of the Web Site and our business;<br>
                                9. To contact you about upcoming promotions and offers from our partners;<br>
                                10. To invite you to participate in market research and surveys; and
                                11. To otherwise to promote our Web Site and our businesses.</p>
                           

                        </div>
        			</div>
        
        		</div>
        	
        	</div>
        </section>
       
        
    </body>
</html>