
        <!--================Header Menu Area =================-->
        
        <!--================Home Banner Area =================-->
        <section class="home_banner_area" id="home">
            <div class="banner_inner">
				<div class="container">
					<div class="row banner_content">
						
					</div>
				</div>
            </div>
        </section>
        <style>
            p{
                color:black;
            }
        </style>
        <!--================End Home Banner Area =================-->
        
        <!--================Feature Area =================-->
        
        <!--================End Feature Area =================-->
        
        <!--================Interior Area =================-->
        
        <!--================End Interior Area =================-->
        
        <!--================Interior Area =================-->
        <section class="interior_area interior_two">
        	<div class="container">
        		<div class="interior_inner row">
        			<div class="col-lg-12 offset-lg-1">
        				<div class="interior_text">
        				
                            <h4>Shipping Policy</h4>
                            <h3>When will you ship out my order?</h3>
        					<p>We ship most orders within three business days of purchase (excluding Saturdays, Sundays and public holidays). We will try to get your order out within 3 working days after we receive payment confirmation from finance. As soon as we ship it out via J&T Express, NINJA VAN, CITY-LINK Express, we’ll send you a notification with all the shipping details.</p>
                            <h3>When will I receive my order?</h3>
        					<p>Shipping times may vary (do check on each product page for the specific lead time), but you should expect to receive your parcel after shipment processing, 3-7 working days. Dispatch times vary orders confirm after the cut off time (1.00 PM) will be processed as next working day.</p>
                            <h3>How do I check the delivery lead time of a product?</h3>
        					<p>Delivery to some postcodes and outlying areas outside Klang Valley may take a slightly longer period. For further details on delivery lead times, the tracking number will be given once the product is ship out by our logistic team.</p>
                            <h3>How much do you charge for delivery?</h3>
        					<p>Delivery fee RM10 for the majority of West Malaysia. For slightly bigger or heavier orders, the charge is RM20. Simply add a product to the basket which will show you the delivery charge for that item, if you add more items the delivery may change.</p>
           

                        </div>
        			</div>
        
        		</div>
        	
        	</div>
        </section>
       
        

    </body>
</html>