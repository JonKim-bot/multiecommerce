
        <!--================Header Menu Area =================-->
        
        <!--================Home Banner Area =================-->
        <section class="home_banner_area" id="home">
            <div class="banner_inner">
				<div class="container">
					<div class="row banner_content">
						
					</div>
				</div>
            </div>
        </section>
        <style>
            p{
                color:black;
            }
        </style>
        <!--================End Home Banner Area =================-->
        
        <!--================Feature Area =================-->
        
        <!--================End Feature Area =================-->
        
        <!--================Interior Area =================-->
        
        <!--================End Interior Area =================-->
        
        <!--================Interior Area =================-->
        <section class="interior_area interior_two">
        	<div class="container">
        		<div class="interior_inner row">
        			<div class="col-lg-12 offset-lg-1">
        				<div class="interior_text">
        					<h4>RETURN & REFUND POLICY</h4>
                            <p>

                                There is no refund and cancellation allowed.
                            </p>
                        </div>
        			</div>
        
        		</div>
        	
        	</div>
        </section>
       
    
    </body>
</html>