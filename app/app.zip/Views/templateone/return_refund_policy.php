
        <!--================Header Menu Area =================-->
        
        <!--================Home Banner Area =================-->
        <section class="home_banner_area" id="home">
            <div class="banner_inner">
				<div class="container">
					<div class="row banner_content">
						
					</div>
				</div>
            </div>
        </section>
        <style>
            p{
                color:black;
            }
        </style>
        <!--================End Home Banner Area =================-->
        
        <!--================Feature Area =================-->
        
        <!--================End Feature Area =================-->
        
        <!--================Interior Area =================-->
        
        <!--================End Interior Area =================-->
        
        <!--================Interior Area =================-->
        <section class="interior_area interior_two">
        	<div class="container">
        		<div class="interior_inner row">
        			<div class="col-lg-12 offset-lg-1">
        				<div class="interior_text">
        					<h4>RETURN & REFUND POLICY</h4>
        					<p>1. Should there be any discrepancy of products delivered and Customer wishes for return and refund, Customer need to notify Customer Service by phone 016-7488035 or email kelvin_piegen@outlook.com to report on the products upon 3 days of receiving the goods. Please allow up to 7 working days for your inquiry to be processed.<br>
                                2. Return/Refund of Products can be arranged under the following reasons:<br>
                                • If the products delivered is in damaged or defective condition; or<br>
                                • If the products is near expiry or expired; or<br>
                                • If the product is different from the Order delivered. Products for return or refund shall be returned in its original condition, quantity and packaging as it first delivered to customer together with proof of purchase.</p><br>
                            <h4>EXCHANGE POLICY</h4>
        					<p>1. For exchange, please email our Customer Service by phone at 016-7488035 or email kelvin_piegen@outlook.com with your order number and information on the affected item within 3 days of receiving the goods.<br>
                                2. Exchange of Products can be arranged under the following reasons: a. If the products delivered is in damaged or defective condition; or b. If the products is near expiry or expired; or c. If the product is different from the Order delivered. Products for exchange shall be returned in its original condition, quantity and packaging as it first delivered to customer together with proof of purchase.<br>
                                3. Exchange of Products can only be for the following: a. Products has to be exchange with the same product. b. Products has to be of the same brand. c. Products has to be of the same quantity & volume size.</p>
           

                        </div>
        			</div>
        
        		</div>
        	
        	</div>
        </section>
       
    
    </body>
</html>