<!DOCTYPE html>
<html lang="en">
    <head>
        <base href="./">
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1.0, shrink-to-fit=no">
        <title>Ecommerce Order Management Panel</title>
        <link rel="stylesheet" href="https://unpkg.com/@coreui/icons@1.0.0/css/all.min.css">
        <!-- Main styles for this application-->
        <link href="<?=base_url()?>/assets/css/core/style.css" rel="stylesheet">
		<link href="<?=base_url()?>/assets/css/core/custom.css" rel="stylesheet">
        <link rel="stylesheet" href="<?= base_url('assets/plugins/select2/select2.css') ?>">

    </head>
    <body class="c-app flex-row align-items-center">
        <div class="container">
            <div class="row justify-content-center">
			